import { defaultProvider } from './unit'
import { ethers } from 'ethers'

// 测试gas手续费
async function a() {
  let gasPrice = await defaultProvider.getGasPrice()
  console.log(gasPrice)
  let eee = gasPrice.toNumber()
  console.log(eee)
  let gasPriceString = gasPrice.add(42100000000)
  let ad = gasPriceString.toNumber()
  let bb = ethers.utils.bigNumberify(ad)
  console.log(bb)
}
// a()
export {a}
