// import address from './addressTrc'
const TronWeb = require('tronweb')
var request = require('request')
import { Decimal } from 'decimal.js'

const url = 'https://api.trongrid.io' // 主网地址
const trc20ContractAddress = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t' //主网USDT

// const url = 'https://api.shasta.trongrid.io' //测试地址
// const trc20ContractAddress = 'TQQg4EL8o1BSeKJY4MJ8TB8XK7xufxFBvK' //测试 contract address

const HttpProvider = TronWeb.providers.HttpProvider
const fullNode = new HttpProvider(url)
const solidityNode = new HttpProvider(url)
const eventServer = new HttpProvider(url)

class WalletTRC20 {
  wallet: any
  address: string
  contract: any
  privateKey: string
  //查看钱包Trx数量
  async getTrxCount() {
    try {
      //根据私钥找回钱包信息
      // pending 在打包中的块
      // latest 最近开采的区块
      let balance = await this.wallet.trx.getBalance(this.address)
      return balance ? Number(Decimal.div(balance, 1000000)) : 0
    } catch (error) {
      console.error(error)
      return 0
    }
  }
  //转出Trx
  async sendTrx(toAddress: string, connt: number) {
    try {
      let d = await this.wallet.trx.sendTransaction(
        toAddress,
        parseInt(Decimal.mul(connt, 1000000) + ''),
        this.privateKey
      )
      return d.txid ? d.txid : 0
    } catch (error) {
      console.error(error)
      return 0
    }
  }

  //查看钱包USDT数量
  async getUsdtCount() {
    try {
      if (!this.contract) {
        this.contract = await this.wallet.contract().at(trc20ContractAddress)
      }
      let result = await this.contract.balanceOf(this.address).call()
      const balance = result.toNumber()
      return balance ? Number(Decimal.div(balance, 1000000)) : 0
    } catch (error) {
      console.error(error)
      return 0
    }
  }

  //转出USDT
  async sendUsdt(toAddress: string, connt: number) {
    try {
      if (!this.contract) {
        this.contract = await this.wallet.contract().at(trc20ContractAddress)
      }
      const data = await this.contract
        .transfer(
          toAddress, //address _to
          parseInt(Decimal.mul(connt, 1000000) + '') //amount
        )
        .send({
          feeLimit: 10000000,
          // callValue: 0,
          // shouldPollResponse: true,
        })
      return data
    } catch (error) {
      return error
    }
  }
  constructor(user: any) {
    if (user && user.privateKey) {
      //let privateKey = address.decode(user.privateKey, user.passwordKey)
      const privateKey1 =
        'D0736FA58EDF546D8848836A6629BE2992DAEB34A5D155D8F7DF3BE727951A49'

      //let privateKey1 = address.encode(privateKey, user.passwordKey)
      //console.log(privateKey1)
      let privateKey = user.privateKey
      if(privateKey1==privateKey){
        console.log(1)
      }

      this.wallet = new TronWeb(fullNode, solidityNode, eventServer, privateKey)
      //console.log(this.wallet.address.fromPrivateKey(privateKey))
      this.address = user.address
      this.privateKey = privateKey
    }
  }
}

const getStatusByHash = (hash: string) => {
  const url = `http://www.tokenview.com:8088/tx/confirmation/trx/${hash}`
  return new Promise((resolve, reject) => {
    request(url, {}, (error: any, _: any, body: any) => {
      if (error) {
        reject(error)
      } else {
        if (body && body.indexOf('"msg":"成功"') != -1) {
          resolve(JSON.parse(body))
        } else {
          reject('查询hash记录失败')
        }
      }
    })
  })
}
// getStatusByHash(
//   '0383ce8d4e8f368d42b23cabdf36dea3727a253f0aaba28ebc4c04fd374760d4'
// )
const createTRC20Wallet = async () => {
  return await TronWeb.createAccount()
}
export { WalletTRC20, getStatusByHash, createTRC20Wallet }

// 5cff130497a5a0ce9c8880e481a2d31e21cad40eae17850bd4b080f7cd6afe6a
// TQnnw7Zc1M5UxuCmUDAp3y6N1mVaifhx2U

