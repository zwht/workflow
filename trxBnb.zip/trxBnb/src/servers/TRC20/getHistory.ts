/*
 * @Descripttion:
 * @version:
 * @Date: 2019-07-18 15:29:56
 * @LastEditTime: 2020-04-12 12:44:02
 */
import * as request from 'request'
let baseEthUrl = 'https://kovan-api.ethplorer.io'

let getHistory = async () => {
  request.get(
    baseEthUrl +
      '/getAddressTransactions/' +
      '0x9548f567Aa2bf71a6691B634F9808346C804c0D0' +
      '?apiKey=freekey',
    (err, _, data) => {
      console.log(err)
      console.log(data)
    }
  )
}
getHistory()

export { getHistory }
