import { ethers } from 'ethers'

export const newWallet = {
  // 使用随机数作为私钥创建钱包账号
  byBytes32() {
    var key = ethers.utils.randomBytes(32)
    var wallet = new ethers.Wallet(key)
    console.log('账号地址: ' + wallet.address)
    return {
      key,
      wallet
    }
  },
  // 通过助记词方式创建钱包账号
  byWord() {
    const rand = ethers.utils.randomBytes(16)
    // 生成助记词
    const mnemonic = ethers.utils.HDNode.entropyToMnemonic(rand)
    const path = "m/44'/60'/0'/0/0"
    // 通过助记词创建钱包
    const wallet = ethers.Wallet.fromMnemonic(mnemonic, path)
    return {
      key: mnemonic,
      path,
      wallet
    }
  },
  // 直接创建一个随机钱包
  create() {
    return {
      wallet: ethers.Wallet.createRandom()
    }
  }
}
