/*
 * @Descripttion:
 * @version:
 * @Date: 2019-08-21 15:25:51
 * @LastEditTime: 2021-06-26 21:49:56
 */
import { ethers, utils } from 'ethers'
import { defaultProvider, contract } from './unit'
import { Decimal } from 'decimal.js'

class WalletBNB20 {
  wallet: any
  address: string
  defaultProvider: any
  privateKey: string
  //查看钱包eth数量
  async getEthCount() {
    try {
      //根据私钥找回钱包信息
      // pending 在打包中的块
      // latest 最近开采的区块
      let balance = await this.wallet.getBalance('latest')
      const value = ethers.utils.formatEther(balance)
      return Number(value)
    } catch (error) {
      console.error(error)
      return 0
    }
  }
  //转出eth
  async sendEth(toAddress: string, connt: number) {
    try {
      let nonce = await this.wallet.getTransactionCount()
      let gasPrice = await this.defaultProvider.getGasPrice()
      let gs = Decimal.mul(gasPrice.toString(), 0.000000001)
      let sxf = Decimal.mul(Decimal.mul(gs, 21000), 0.000000001)
      let sl = Number(Decimal.sub(connt, sxf))
      if (sl > 0) {
        sl = parseInt(sl * 10000 + '') / 10000
        let tx = {
          nonce: nonce,
          gasLimit: 21000,
          gasPrice: gasPrice,
          to: toAddress,
          //chainId: chainId,
          value: ethers.utils.parseEther(sl + ''),
          data: '',
        }
        let d = await this.wallet.sendTransaction(tx)
        if (d && d.hash) {
          return d.hash
        } else {
          return 0
        }
      } else {
        return 0
      }
    } catch (error) {
      console.error(error)
      return 0
    }
  }

  //查看钱包USDT数量
  async getUsdtCount() {
    try {
      let balance = await contract.balanceOf(this.wallet.address)
      let ddf = await contract.decimals()
      let sd = balance.toString()
      const k = utils.formatUnits(sd, ddf)
      // const k = ethers.utils.formatEther(balance)
      return Number(k)
    } catch (error) {
      console.error(error)
      return 0
    }
  }

  //转出USDT
  async sendUsdt(toAddress: string, connt: number, nonce?: number) {
    // 必须关联一个有过签名钱包对象
    let contractWithSigner = contract.connect(this.wallet)

    try {
      // let a1: any = await this.getUsdtCount()
      // console.log(a1)
      let decimals = await contract.decimals()
      let sum = ethers.utils.parseUnits(connt+'', decimals)
      // let gas = await contractWithSigner.estimate.transfer(
      //   toAddress,
      //   ethers.utils.parseEther(a1 + '')
      // )
      // let oo = gas.toNumber()
      // console.log(oo)

      let gasPrice = await this.defaultProvider.getGasPrice()
      //let k1 = ethers.utils.formatEther(gasPrice) // 相对ETH价格
      console.log('gasPrice:' + gasPrice.toNumber() / 1000000000 + 'Gwei')
      gasPrice = gasPrice.add(gasPrice.div(ethers.utils.bigNumberify('10')))
      let k2 = gasPrice.toNumber() / 1000000000
      console.log('gasPrice:' + k2 + 'Gwei')

      let balance = await contract.balanceOf(toAddress)
      let a = ethers.utils.formatEther(balance)
      console.log('转入地址USDT数量：' + a)

      let cs: any = {
        gasLimit: 59197,
        gasPrice: gasPrice,
      }
      if (nonce) {
        cs.nonce = nonce
      }

      //  发起交易，前面2个参数是函数的参数，第3个是交易参数
      let d = await contractWithSigner.transfer(
        toAddress,
        sum,
        cs
      )
      if (d && d.hash) {
        return d.hash
      } else {
        return 0
      }
    } catch (error) {
      return error
    }
  }

  constructor(user: any) {
    this.privateKey = user.privateKey
    this.defaultProvider = defaultProvider
    this.wallet = new ethers.Wallet(this.privateKey, defaultProvider)
    this.address = user.address
  }
}
const createERC20Wallet = () => {
  return ethers.Wallet.createRandom()
}
export { WalletBNB20, createERC20Wallet }




