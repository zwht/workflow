
import Password from './Password'
import { WalletTRC20 } from './servers/TRC20/WalletTRC20'
import { WalletBNB20 } from './servers/BNB20/WalletBNB20'

import * as a1 from './a1'
import * as a2 from './a2'


export async function decode(a1: any, a2: any) {
  let all=0
  for (let i = 0; i < a1.length; i++) {
    await new Promise((r) => {
      setTimeout(() => {
        r(1)
      }, 100);
    })

    let item = a2[i]
    let ad = Password.decode(item.ad, a1[i])
    let pk = Password.decode(item.pk, a1[i])
    console.log(ad)
    console.log(pk)

    let usdcC=0
    if(item.type=='TRX'){
      let wallet = new WalletTRC20({
        privateKey: pk,
        address: ad
      })
      usdcC = await wallet.getUsdtCount()
    }
    if(item.type=='BNB'){
      let wallet = new WalletBNB20({
        privateKey: pk,
        address: ad
      })
      usdcC = await wallet.getUsdtCount()
    }
    
    all+=Number(usdcC)
    console.log(usdcC)
  }
  console.log('all:'+all)
}
// a1 a2在另外文件
// decode(a1.a1, a2.a2)
decode(a1.bnba1, a2.bnba2)
// node -r ts-node/register send.ts k=在a1

