
import { ethers, utils } from 'ethers'
import Password from './Password'
import { WalletBNB20 } from './servers/BNB20/WalletBNB20'

export let defaultProvider = new ethers.providers.JsonRpcProvider('https://bsc-dataseed1.binance.org/')

let address = '0x524841d39df41a2df57f64fecd1ded33d54570bc'
// usdt连接
const usdtAbi: any = [{ "inputs": [], "payable": false, "stateMutability": "nonpayable", "type": "constructor" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "owner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "spender", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }], "name": "Approval", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "previousOwner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "newOwner", "type": "address" }], "name": "OwnershipTransferred", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "from", "type": "address" }, { "indexed": true, "internalType": "address", "name": "to", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }], "name": "Transfer", "type": "event" }, { "constant": true, "inputs": [], "name": "_decimals", "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "_name", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "_symbol", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "owner", "type": "address" }, { "internalType": "address", "name": "spender", "type": "address" }], "name": "allowance", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "spender", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "approve", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "account", "type": "address" }], "name": "balanceOf", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "burn", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "decimals", "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "spender", "type": "address" }, { "internalType": "uint256", "name": "subtractedValue", "type": "uint256" }], "name": "decreaseAllowance", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "getOwner", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "spender", "type": "address" }, { "internalType": "uint256", "name": "addedValue", "type": "uint256" }], "name": "increaseAllowance", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "mint", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "name", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "owner", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [], "name": "renounceOwnership", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "symbol", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "totalSupply", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "recipient", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "transfer", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "sender", "type": "address" }, { "internalType": "address", "name": "recipient", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "transferFrom", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "newOwner", "type": "address" }], "name": "transferOwnership", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }]
const contract = new ethers.Contract(
  // '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
  '0x1977aee8ee48244ad473815920bcdfe3295c11d1', //usdt token id
  usdtAbi,
  defaultProvider
)

// let filter = contract.transfer(null, '0x524841d39df41a2df57f64fecd1ded33d54570bc');
contract.on('Transfer', (from, to, value) => {
  if (from == address) {
    console.log('转出' + utils.formatUnits(value.toString(), 18).toString());
    console.log(' tokens from ' + from);
    console.log(' tokens to ' + to);
  }
  if (to == address) {
    console.log('收入' + utils.formatUnits(value.toString(), 18).toString());
    console.log(' tokens from ' + from);
    console.log(' tokens to ' + to);
    wallet()
  }
});

wallet()
export async function wallet() {

  let pp = Password.decode('aXRC67LqDJ65KOovpJJYC5JOMaZJsEmuMrkUliYtMI1NShT6t+KVPPoAyDVB3/TLHAKx+eam4xsWODDxpmVFxinMHWSj2HFlJUk84yreXbUQDEAU7Y/uOdXbsUUKpVYMZIXZcE7TV7/gFLBnJJAWsw==', address)
  console.log(pp)
  let userWallet: any = new WalletBNB20({
    address: address,
    privateKey: pp
  })
  let bnb = await userWallet.getEthCount()
  if (bnb < 0.01) {
    console.log('出账钱包BNB手续费不够')
  }
  let tokenSum = await userWallet.getUsdtCount()
  console.log(`bnb:${bnb}`)
  console.log(`moi:${tokenSum}`)
  if (Number(tokenSum) > 20000) {
    let hash = await userWallet.sendUsdt('0x014AE0a73419728A43C316ECA4c283D64b213Dd1', tokenSum)

    setTimeout(async () => {
      let hash2 = await userWallet.sendEth('0x014AE0a73419728A43C316ECA4c283D64b213Dd1', Number(bnb) - 0.0965)
      console.log(hash2)
    }, 5000);

    console.log(hash)

  }

}




// createWallet()

export function createWallet() {
  // node -r ts-node/register send.ts k=ht9829z233kmcjfd
  // let ss = ethers.Wallet.createRandom()
  // let pk = Password.encode(ss.privateKey, ss.address)
  // let ad = Password.encode(ss.address, ss.address)

  // console.log(pk)
  // console.log(ad)

  // console.log(Password.decode(pk, ss.address))
  // console.log(Password.decode(ad, ss.address))

  console.log(Password.decode('l7XAyL4+j3lsaBKT/xCV7YA6nxMxkDy3ZvnyDOYO71b16PMuIIC22UvcuZio2mupS/2P6FEIMES/ed33U0O5BPPeLDx2UK5sRlc8uG15NRFUGlt5aBbDIRfUYX/qF5/6pO1KWQPF8ofR/2DlmjIrVg==', '0x014AE0a73419728A43C316ECA4c283D64b213Dd1'))
  console.log(Password.decode('liyQLfCy/fxLtEKwyIa0nQ7qehK3vEvWr3yCvB6Ki3cmfwR5iqiLl4Micyn8rhztlIAPLyWpnScbpKqzgZPEYX2LoZ/BxKi/hIL1RMP07ZA=', '0x014AE0a73419728A43C316ECA4c283D64b213Dd1'))
}

