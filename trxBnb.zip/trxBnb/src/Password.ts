/*
 * @Descripttion:
 * @version:
 * @Date: 2019-09-02 09:04:27
 * @LastEditTime: 2021-07-11 13:49:06
 */
import * as crypto from 'crypto'

/**
 * 加密方法
 * @param key 加密key
 * @param iv       向量
 * @param data     需要加密的数据
 * @returns string
 */
var encrypt = function (key: string, iv: string, data: string) {
  var cipher = crypto.createCipheriv('aes-128-cbc', key, iv)
  var crypted = cipher.update(data, 'utf8', 'binary')
  crypted += cipher.final('binary')
  crypted = Buffer.from(crypted, 'binary').toString('base64')
  return crypted
}

/**
 * 解密方法
 * @param key      解密的key
 * @param iv       向量
 * @param crypted  密文
 * @returns string
 */
var decrypt = function (key: string, iv: string, crypted: string) {
  crypted = Buffer.from(crypted, 'base64').toString('binary')
  var decipher = crypto.createDecipheriv('aes-128-cbc', key, iv)
  var decoded = decipher.update(crypted, 'binary', 'utf8')
  decoded += decipher.final('utf8')
  return decoded
}

interface Password {
  strKeys: any
  encode: (str: string, k: string, le?: number) => any
  decode: (str: string, k: string, le?: number) => any
}
var password: Password = {
  strKeys: [
    'q',
    'w',
    'e',
    'r',
    't',
    'y',
    'u',
    'i',
    'o',
    'p',
    'a',
    's',
    'd',
    'f',
    'g',
    'h',
    'j',
    'k',
    'l',
    'z',
    'x',
    'c',
    'v',
    'b',
    'n',
    'm',
    'A',
    'W',
    'E',
    'R',
    'T',
    'Y',
    'U',
    'I',
    'O',
    'P',
    'A',
    'S',
    'D',
    'F',
    'G',
    'H',
    'J',
    'K',
    'L',
    'Z',
    'X',
    'C',
    'V',
    'B',
    'N',
    'M',
    '0',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
  ],
  encode: function (str, key, le) {
    if (!process.argv[2]) return
    if (!le) le = 5
    let fKey = key
    if (fKey.length > 16) fKey = fKey.substr(0, 16)
    const hash = crypto.createHash('md5')
    hash.update(key + process.argv[2])
    hash.update(key)
    key = hash.digest('hex')
    let frist = key.substr(0, 1)
    let index = 0
    this.strKeys.forEach((item: any, i: any) => {
      if (item === frist) {
        index = parseInt(i / le + '')
      }
    })
    str = str.substring(0, index) + key + str.substring(index)
    str =
      str.substring(str.length - 10, str.length) +
      str.substring(0, str.length - 10)
    return encrypt(fKey, fKey, str)
  },
  decode: function (str, key, le) {

    if (!process.argv[2]) return
    if (!le) le = 5
    let fKey = key
    if (fKey.length > 16) fKey = fKey.substr(0, 16)
    str = decrypt(fKey, fKey, str)
    const hash = crypto.createHash('md5')
    hash.update(key + process.argv[2])
    hash.update(key)
    key = hash.digest('hex')
    let frist: any = key.substr(0, 1)
    let index = 0
    this.strKeys.forEach((item: any, i: any) => {
      if (item === frist) {
        index = parseInt(i / le + '')
      }
    })
    str = str.substring(10, str.length) + str.substring(0, 10)
    str =
      str.substring(0, index) + str.substring(key.length + index, str.length)
    return str
  },
}

export default password
